$().click(
    function(){
        var color = $().css();
        $().css();
        $().text();
    }
);

 