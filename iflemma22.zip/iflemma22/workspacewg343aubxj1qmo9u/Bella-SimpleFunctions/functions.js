$('#myButton').click(
function() {
var userName = $('#infoBox').val();
    $('#result').text("You are fool "+ userName);
    }
);


