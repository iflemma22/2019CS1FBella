$('#sumButton').click(
    function(){
        
        /*
         * HINT: parseInt() -  https://www.w3schools.com/jsref/jsref_parseint.asp 
         * 
         **/
        var a = parseInt($('#sumA').val());
        var b = parseInt($('#sumB').val());
        
        var sum = a+b;
        
        $('#sumTotal').text(sum);
        
    }
);

$('#productButton').click(
    function(){
        
        /*
         * HINT: parseInt() -  https://www.w3schools.com/jsref/jsref_parseint.asp 
         * 
         **/
        var a = parseInt($('#productA').val());
        var b = parseInt($('#productB').val());
        
        var product = a*b;
        
        $('#productTotal').text(product);
        
    }
);

$('#differenceButton').click(
    function(){
        
        /*
         * HINT: parseInt() -  https://www.w3schools.com/jsref/jsref_parseint.asp 
         * 
         **/
        var a = parseInt($('#differenceA').val());
        var b = parseInt($('#differenceB').val());
        
        var product = a-b;
        
        $('#differenceTotal').text(product);
        
    }
);

$('#quotientButton').click(
    function(){
        
        /*
         * HINT: parseInt() -  https://www.w3schools.com/jsref/jsref_parseint.asp 
         * 
         **/
        var a = parseInt($('#quotientA').val());
        var b = parseInt($('#quotientB').val());
        
        var product = a/b;
        
        $('#quotientTotal').text(product);
        
    }
);

